                                        
            ./oyhhhhhhhhyo:.            
         -sdy+-`        `-+yds-         
       /dy:                  :yd/       
     -dy.                      .yd-     
    +N:                          :N+    
   +N-        ./syhyo.  -hddds`   -N+   	
  .N/       /dMMMMMMMMs.NMMNo      /N.  
  sd      `hMMMm+:/dMMMh/Nd-        ds  
  ds      dMMMo     dMMMd-          sd  
  ds     /MMMs    :dMMMMMd`         sd  
  sm     -MMMs .+dMMMNyMMMmo+       ms  
  .N/     +NMMMMMMMmo` :mMMMy      /N.  
   +N-     `+yhdyo-     `+ys`     -N+   
    +N/                          /N+    
     -dy.                      .yd-     
       /dh:                  :hd/       
         -sdh+:.        .:+hds-         
            `:oyhhhhhhhhyo:`            
                                        

Agung Rohmat - alphArt
displayart20@gmail.com
https://alphartype.com

-----------------------------------------------------------
FREE FOR PERSONAL USE ONLY
-----------------------------------------------------------

License Usage :

Only for PERSONAL USE !!!
No Commercial use allowed
Link to purchase commercial license :
https://alphartype.com/product/colorado/

-----------------------------------------------------------
TERMS
-----------------------------------------------------------

Commercial Use is any use:
(i) that involves an exchange of money or other consideration,
(ii) that promotes a business (e.g., sole proprietorship, corporation, or partnership), product, or service, or
(iii) where financial gain or other consideration is either sought or a result, directly or indirectly, of Licensee’s use of the Licensed Asset.
If any one or more of the criteria in (i), (ii), and (iii) is met, then the use is deemed “Commercial”.

Non-Commercial Use (Personal):
Non-commercial Use is a use for solely personal purposes; any use that meets the definition of “Commercial Use” can not be a Non-commercial use.

-----------------------------------------------------------
-----------------------------------------------------------

YOU ARE NOT ALLOWED TO :

Sell and Redistribute
The items purchased are for your use only. You cannot sell and redistribute it to any third party.

More User
Allowing more than one user to use items downloaded/purchased from us.

Convert
Converting products into different formats without written permission from us.

Duplicate
You may not duplicate/copy the product to anyone without our permission.

-----------------------------------------------------------
-----------------------------------------------------------

INDONESIA !!! (TRANSLATE)

-----------------------------------------------------------
GRATIS UNTUK PENGGUNAAN PRIBADI SAJA
-----------------------------------------------------------

Penggunaan Lisensi:

Hanya untuk PENGGUNAAN PRIBADI !!!
Penggunaan komersial tidak diizinkan
Hubungi Kami di displayart20@gmail.com untuk Penggunaan Komersial.

-----------------------------------------------------------
KETENTUAN/ISTILAH
-----------------------------------------------------------

Penggunaan Komersial adalah segala penggunaan:
(i) yang melibatkan pertukaran uang atau pertimbangan lain,
(ii) yang mempromosikan bisnis (mis., kepemilikan perseorangan, korporasi, atau kemitraan), produk, atau layanan, atau
(iii) di mana keuntungan finansial atau pertimbangan lain dicari atau hasilnya, secara langsung atau tidak langsung, penggunaan Aset Lisensi oleh Pemegang Lisensi.
Jika ada satu atau lebih kriteria dalam (i), (ii), dan (iii) terpenuhi, maka penggunaannya dianggap “Komersial”.

Penggunaan Non-Komersial (Pribadi):
Penggunaan Non-komersial adalah penggunaan hanya untuk tujuan pribadi; setiap penggunaan yang memenuhi definisi “Penggunaan Komersial” tidak dapat menjadi penggunaan Nonkomersial.

-----------------------------------------------------------
-----------------------------------------------------------

ANDA TIDAK DIIZINKAN UNTUK:

Jual dan Distribusi Ulang
Barang yang dibeli hanya untuk Anda gunakan. Anda tidak dapat menjual dan mendistribusikannya ke pihak ketiga mana pun.

Pengguna Lebih Banyak
Mengizinkan lebih dari satu pengguna menggunakan item yang diunduh / dibeli dari kami.

Mengubah
Mengubah produk menjadi format yang berbeda tanpa izin tertulis dari kami.

Duplikat
Anda tidak boleh menggandakan / menyalin produk kepada siapa pun tanpa izin kami.